import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./assets/components/Header";
import NavBar from "./assets/components/NavBar";
import Footer from "./assets/components/Footer";
import Home from "./assets/components/Home";
import Service from "./assets/components/Service";
import Askthevet from "./assets/components/Askthevet";
import Contact from "./assets/components/Contact";
import Shop from "./assets/components/Shop"
import "./assets/styles/fishcreek.css";

function App() {
    return (
        <Router>
            <div id="wrapper">
                <Header />
                <NavBar />
                <Routes>
                    <Route path="/" element={<Home />}></Route>
                    <Route path="/services" element={<Service />}></Route>
                    <Route path="/askvet" element={<Askthevet />}></Route>
                    <Route path="/shop" element={<Shop />}></Route>
                    <Route path="/contact" element={<Contact/> }></Route>
                </Routes>
                <Footer />
            </div>
        </Router>
  );
}

export default App;
